function [X] = CRAMER(C, A, X, N, M)
% Ian Adler
% Collaborators: Jacob Killelea (github)
% Purpose: Implement Cramers rule from fortran code
CC = zeros(M+1,M+1);
DENOM = det(C);
for K = 1:N
    for I = 1:N
        for J = 1:N
            CC(I,J) = C(I,J);
        end
    end
    for I = 1:N
        CC(I,K) = A(I);
    end
    X(K) = det(CC) / DENOM;
end
end